COURAGE ROAD
A Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com
paula.cumberlandgames.com

This font is a new entry into one of my most popular forms, the stressed poster font. This one is extra bold, though, because it's about one person's courage, and a tribute to the line to their heart. This is the COURAGE ROAD.

PLEASE CONSIDER HELPING: Paula Repko, who inspired this font, needs your help. Visit paula.cumberlandgames.com

COURAGE ROAD is a full US-Keyboard Small-Caps stressed poster font with some extras for additional European alphabets. Enjoy!

This font is copyright © 2021 by S. John Ross. "Cumberland Games & Diversions" and this font's title are trademarks of S. John Ross. This font is free for private use only. Any public or commercial use, any embedded use, or any use by an organization rather than an individual, requires a license; contact the Cumberland Fontworks via email (sjohn@cumberlandgames.com) or find me on the Web for alternate email addresses if that one isn't working. Additional glyphs (foreign alphabet support, customizations, etc) are available by commission.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

1.0 cumberlandgames.com Free For Private Use
http://fonts.cumberlandgames.com
http://private-use.cumberlandgames.com